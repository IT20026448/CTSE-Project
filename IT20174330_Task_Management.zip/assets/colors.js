const colors = {
  gray: "#D1D3D2",
  darkGray: "#676767",
  orange: "#F35D38",
  black: "#0C0D0E",
  white: "#FBFCFE",
  blue: "#1C215D",
  blueFaded: "#8D8FAD",
};

export default colors;
